using System.Collections;
using System.Collections.Generic;
using UnityEditor.Rendering;
using UnityEngine;

public class Player : MonoBehaviour
{
    //�÷��̾� �̵�����
    public Vector2 inputVec;
    public float speed;
    Rigidbody2D rigid;
    SpriteRenderer spriter;
    Animator anim;

    public float interactRadius = 1.5f;

    //�ʱ�ȭ -> awake
    void Awake()
    {
        rigid = GetComponent<Rigidbody2D>();
        spriter = GetComponent<SpriteRenderer>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        inputVec.x = Input.GetAxisRaw("Horizontal");
        inputVec.y = Input.GetAxisRaw("Vertical");

        if (Input.GetKeyDown(KeyCode.E))
        {
            InteractWithDog();
        }
    }

    //����  �̵����
    void FixedUpdate()
    {
        ////1.���� �ش�
        //rigid.AddForce(inputVec);

        ////2. �ӵ� ����
        //rigid.velocity = inputVec;

        Vector2 nextVec = inputVec.normalized * speed * Time.fixedDeltaTime;
        //3. ��ġ �̵�
        rigid.MovePosition(rigid.position + nextVec);
    }

    //�����ֱ� �Լ�
    void LateUpdate()
    {
        anim.SetFloat("Speed", inputVec.magnitude);

        if (inputVec.x != 0)
        
            spriter.flipX = inputVec.x < 0;

        
    }
    void InteractWithDog()
    {
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, interactRadius);

        foreach (var hit in hits)
        {
            Dog dog = hit.GetComponent<Dog>();
            if (dog != null)
            {
                dog.Interact();
                break;
            }
    }
}
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, interactRadius);
    }
    }
