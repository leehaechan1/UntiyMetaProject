using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class NameInputManager : MonoBehaviour
{

    public TMP_InputField nameInputField;
    public GameObject inputPanel;

    public static string playerName;

    public void OnConfirmButtonClicked()
    {
        string inputName = nameInputField.text;

        if(!string.IsNullOrEmpty(inputName))
        {
            playerName = inputName;
            Debug.Log("�÷��̾� �̸�:" + playerName);

            inputPanel.SetActive(false);
        }
    }
    //// Start is called before the first frame update
    //void Start()
    //{
        
    //}

    //// Update is called once per frame
    //void Update()
    //{
        
    //}
}
