using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class SimulatorController : MonoBehaviour
{
    public TMP_Text nicknameText;
    public Image characterImage;
    public Image petImage;
    public Sprite[] characterSprites;
    public Sprite[] petSprites;

    void Start()
    {
        nicknameText.text = $"�г���: {GameData.Nickname}";
        characterImage.sprite = characterSprites[GameData.SelectedCharacterIndex];
        petImage.sprite = petSprites[GameData.SelectedPetIndex];
    }
}
