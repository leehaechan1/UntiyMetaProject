public static class GameData
{
    public static string Nickname;
    public static int SelectedCharacterIndex;
    public static int SelectedPetIndex;
}