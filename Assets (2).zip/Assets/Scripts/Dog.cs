using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Dog : MonoBehaviour
{
    public float moveSpeed = 3f;
    public float runSpeed = 6f;
    public Animator animator;
    SpriteRenderer spriter;

    private Rigidbody2D rb;
    private Vector2 moveInput;
    private bool isRunning;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        if(animator == null)
        {
            animator = GetComponent<Animator>();
        }
        spriter = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        moveInput.x = Input.GetAxisRaw("Horizontal");
        moveInput.y = Input.GetAxisRaw("Vertical");

        isRunning = Input.GetKey(KeyCode.LeftShift);

        float currentSpeed = moveInput.magnitude * (isRunning ? runSpeed : moveSpeed);
        animator.SetFloat("Speed", currentSpeed);

        if (Input.GetKeyDown(KeyCode.X))
        {
            animator.SetTrigger("Hide");
        }

        if(Input.GetKeyDown(KeyCode.Z))
        {
            animator.SetTrigger("Sleep");
        }
    }
    void FixedUpdate()
    {
        float speed = isRunning ? runSpeed : moveSpeed;
        rb.MovePosition(rb.position + moveInput.normalized * speed * Time.fixedDeltaTime);
    }

    void LateUpdate()
    {
        if (moveInput.x != 0)
        {
            spriter.flipX = moveInput.x < 0;
        }
    }
    public void Interact()
    {
        int action = Random.Range(0, 3);
        switch(action)
        {
            case 0:
                animator.SetTrigger("Sit");
                break;
            case 1:
                animator.SetTrigger("Hide");
                break;
            case 2:
                animator.SetTrigger("Eat");
                break;
        }
    }
   
}
