using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DogSelectionEffect : MonoBehaviour
{
    private Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    public void OnSelected()
    {
        animator.SetBool("isSelected", true);
    }

    public void OnDeselected()
    {
        animator.SetBool("isSelected", false);
    }

  
}

