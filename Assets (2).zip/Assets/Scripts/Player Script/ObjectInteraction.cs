using System.Collections;
using System.Collections.Generic;
using System.Net;
using UnityEngine;

public enum InteractionType { Bed, Furniture}

public class ObjectInteraction : Interactable
{
    public InteractionType type;

    public override void Interact()
    {
        switch (type)
        {
            case InteractionType.Bed:
                Debug.Log("���ڱ� ����");
                TimeManager.Instance.SkipTime(8);
                break;
            case InteractionType.Furniture:
                Debug.Log("������ ���캾�ϴ�.");
                break;
        }
    }

}
