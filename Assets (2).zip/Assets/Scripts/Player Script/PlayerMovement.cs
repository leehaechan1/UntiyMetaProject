using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    public float moveSpeed = 3f;
    public float interactRange = 1.5f;
    public LayerMask interactLayer;

    [Header("Components")]
    private Rigidbody2D rb;
    private Animator animator;
    private SpriteRenderer spriteRenderer;

    private Vector2 moveInput;
    private Interactable currentTarget;

    public UIManager uiManager;
    

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        // �Է¹ޱ�
        moveInput.x = Input.GetAxisRaw("Horizontal");
        moveInput.y = Input.GetAxisRaw("Vertical");

        //��ȣ�ۿ� ��� ã��
        Collider2D hit = Physics2D.OverlapCircle(transform.position, interactRange, interactLayer);
        if (hit)
            currentTarget = hit.GetComponent<Interactable>();
        else
            currentTarget = null;

        // EŰ ��ȣ�ۿ�
        if (currentTarget != null && Input.GetKeyDown(KeyCode.E))
        {
            if (currentTarget is DogInteraction dogInteraction)
            {
                // �������� ��ȣ�ۿ� �� UI ����
                uiManager.ShowInteractionUI(dogInteraction);
            }
            else
            {
                // �ٸ� �繰�� ��ȣ�ۿ�
                currentTarget.Interact();
            }
        }
        //�ִϸ��̼� �Ķ���� ����
        bool isMoving = moveInput != Vector2.zero;
        animator.SetBool("isMoving", isMoving);

        //������ �̵� ���� ���� (idle�� ���� ����)
        if (isMoving)
        {
            animator.SetFloat("moveX", moveInput.x);
            animator.SetFloat("moveY", moveInput.y);
        }
    }

    void FixedUpdate()
    {
        rb.MovePosition(rb.position + moveInput.normalized * moveSpeed * Time.fixedDeltaTime);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, interactRange);
    }
}
