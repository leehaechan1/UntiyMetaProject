// UIManager.cs (������ �ڵ�)
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;
    public GameObject dogInteractionPanel;
    public TextMeshProUGUI eventText;
    public Button[] optionButtons;

    private DogInteraction currentDogInteraction;

    void Awake()
    {
       if (Instance != null && Instance != this)
        {
            Destroy(this.gameObject);
        }
        else
        {
            Instance = this;
        }
    }

    public void UpdateTime(int Hour)
    {

    }

    public void ShowInteractionUI(DogInteraction dog)
    {
        currentDogInteraction = dog;
        if (dogInteractionPanel != null)
        {
            // �̺�Ʈ �ؽ�Ʈ ����
            eventText.text = dog.dogAI.GetCurrentEvent();
            // ��ư�� �̺�Ʈ ������ ����
            optionButtons[0].onClick.RemoveAllListeners();
            optionButtons[0].onClick.AddListener(() => OnOptionSelected(0));

            dogInteractionPanel.SetActive(true);
        }
    }

    public void OnOptionSelected(int optionIndex)
    {
        currentDogInteraction.InteractWithOption(optionIndex);
        dogInteractionPanel.SetActive(false);
    }
}