using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeManager : MonoBehaviour
{

    public static TimeManager Instance;
    public int hour = 8;
    public float timeScale = 60f;
    private float timer;

    void Awake() => Instance = this;

    void Update()
    {
        timer += Time.deltaTime * timeScale;
        if (timer >= 60f)
        {
            hour++;
            if (hour >= 24) hour = 0;
            timer = 0;
            UIManager.Instance.UpdateTime(hour);
        }
    }

    public void SkipTime(int hours)
    {
        hour = (hour + hours) % 24;
        UIManager.Instance.UpdateTime(hour);
    }

    public bool IsDay() => hour >= 6 && hour < 18;
}