using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class BtnType : MonoBehaviour,IPointerEnterHandler, IPointerExitHandler
{
    public BTNType currentType;
    public Transform buttonScale;
    Vector3 defaultScale;

    private void Start()
    {
        
        
            defaultScale = buttonScale.localScale;
        
    }
    bool isSound;
    public void OnBtnClick()
    {
        switch(currentType)
        {
            case BTNType.New:
                break;
            case BTNType.Continue:
                break;
            case BTNType.Option:
                Debug.Log("�ɼ�");
                break;
            case BTNType.Sound:
                if (isSound)
                {
                    isSound = !isSound;
                    Debug.Log("����OFF");
                }
                break;
            case BTNType.Back:
                Debug.Log("�ڷΰ���");
                break;
            case BTNType.Quit:
                Debug.Log("������");
                break;
        }
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        buttonScale.localScale = defaultScale * 1.2f;
     }
    public void OnPointerExit(PointerEventData eventData)
    {
        buttonScale.localScale = defaultScale;
    }
}
